"""Execute ordinary Python notebook cells sequentially and capture explicit displays.

This runner uses a fresh Python process, not a Jupyter kernel. It supports this
project's imports, print(), IPython display(), and matplotlib show(). For an
independent Jupyter/Kaggle check, use Restart and Run All in that environment.
"""
import argparse
import base64
import contextlib
import io
import json
import os
from pathlib import Path
import sys
import time
from datetime import datetime, timezone


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('notebook', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    src = args.notebook.resolve()
    dest = args.output.resolve()
    os.environ.setdefault('MPLBACKEND', 'Agg')
    import IPython.display as ipd
    import matplotlib.pyplot as plt
    nb = json.loads(src.read_text(encoding='utf-8'))
    namespace = {'__name__': '__main__'}
    current = []

    class Stream:
        encoding = 'utf-8'
        def __init__(self, name): self.name = name
        def write(self, value):
            if not value: return 0
            if current and current[-1].get('output_type') == 'stream' and current[-1]['name'] == self.name:
                current[-1]['text'] += value
            else: current.append({'output_type':'stream','name':self.name,'text':value})
            return len(value)
        def flush(self): pass
        def isatty(self): return False

    def display(*objects, **kwargs):
        for obj in objects:
            data = {'text/plain':str(obj)}
            html = getattr(obj, '_repr_html_', None)
            if html:
                value = html()
                if value is not None: data['text/html'] = value
            current.append({'output_type':'display_data','data':data,'metadata':{}})

    def show(*args, **kwargs):
        for number in plt.get_fignums():
            fig = plt.figure(number)
            buffer = io.BytesIO()
            fig.savefig(buffer, format='png', dpi=120, bbox_inches='tight')
            current.append({'output_type':'display_data','data':{
                'text/plain':repr(fig), 'image/png':base64.b64encode(buffer.getvalue()).decode('ascii')},'metadata':{}})
        plt.close('all')

    ipd.display = display
    plt.show = show
    started = datetime.now(timezone.utc).isoformat()
    count = 0
    previous = Path.cwd()
    os.chdir(src.parent)
    try:
        for index, cell in enumerate(nb['cells']):
            if cell['cell_type'] != 'code': continue
            count += 1
            current = []
            start = time.perf_counter()
            with contextlib.redirect_stdout(Stream('stdout')), contextlib.redirect_stderr(Stream('stderr')):
                exec(compile(''.join(cell['source']), f'{src.name}:cell_{index}', 'exec'), namespace)
            cell['execution_count'] = count
            cell['outputs'] = current
            cell.setdefault('metadata', {})['execution_seconds'] = round(time.perf_counter()-start, 6)
    finally:
        os.chdir(previous)
    nb['metadata']['project12_execution'] = {
        'method':'sequential Python cell executor with captured explicit displays; no Jupyter kernel',
        'started_utc':started, 'finished_utc':datetime.now(timezone.utc).isoformat(),
        'code_cells_executed':count,'status':'PASS','kaggle_execution_independently_verified':False}
    dest.write_text(json.dumps(nb, ensure_ascii=False, indent=1)+'\n', encoding='utf-8')
    print(f'PASS: {count} code cells; no execution errors; saved {dest.name}')

if __name__ == '__main__': main()
