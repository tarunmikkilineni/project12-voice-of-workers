# Uploaded input workflow clarification

The current notebook defines rows directly in its second code cell and reads only the baseline CSV it exports before running the sensitivity supplement. It does not consume the starter cases.csv, documents.csv or published_fairwork_scores_reference.csv, and does not read the four missing policy-coding CSVs named in the uploaded README.

The supplied inputs are retained for traceability. The report roster contains 15 platform cases. The documents table has 15 platform-linked rows but a single unique report URL; it is not 15 independent documents. Local paths and policy validity dates remain blank. Starter analysis dates do not establish historical policy validity, and GLOBAL does not establish jurisdiction-specific legal applicability.

No empirical policy-coding dataset is claimed. If the project returns to the original policy-document study, it will require dated policy sources, evidence excerpts, explicit codes, Fairwork comparisons and independent coding. These cannot be inferred from overall published ratings.
